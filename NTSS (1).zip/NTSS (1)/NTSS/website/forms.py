'''from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField, TextAreaField, RadioField
from wtforms.validators import DataRequired, Email'''''
from flask_wtf import FlaskForm
from wtforms import StringField, IntegerField, SubmitField, DateField, TextAreaField, RadioField
from wtforms.validators import DataRequired, Email

class EventForm(FlaskForm):
    name = StringField('Event Name', validators=[DataRequired()])
    description = TextAreaField('Event Description', validators=[DataRequired()])
    submit = SubmitField('Submit')

class ParticipantForm(FlaskForm):
    name = StringField('Name', validators=[DataRequired()])
    role = RadioField('Role', choices=[('speaker', 'Speaker'), ('exhibitor', 'Exhibitor'), ('observer', 'Observer')], validators=[DataRequired()])
    submit = SubmitField('Submit')

class RequestResetForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    submit = SubmitField('Request Password Reset')

class BoothSearchForm(FlaskForm):
    start_date = DateField('Start Date', validators=[DataRequired()])
    end_date = DateField('End Date', validators=[DataRequired()])
    submit = SubmitField('Search for Available Booths')

class BoothRentalForm(FlaskForm):
    booth_number = IntegerField('Booth Number', validators=[DataRequired()])
    participant_e_number = StringField('Participant E-number', validators=[DataRequired()])
    start_date = DateField('Start Date', validators=[DataRequired()])
    end_date = DateField('End Date', validators=[DataRequired()])
    submit = SubmitField('Rent Booth')

class BoothModificationForm(FlaskForm):
    booth_number = IntegerField('Booth Number', validators=[DataRequired()])
    participant_e_number = StringField('Participant E-number', validators=[DataRequired()])
    start_date = DateField('Start Date', validators=[DataRequired()])
    end_date = DateField('End Date', validators=[DataRequired()])
    submit = SubmitField('Modify Booth Rent')

class PaymentForm(FlaskForm):
    booth_number = IntegerField('Booth Number', validators=[DataRequired()])
    participant_e_number = StringField('Participant E-number', validators=[DataRequired()])
    start_date = DateField('Start Date', validators=[DataRequired()])
    end_date = DateField('End Date', validators=[DataRequired()])
    submit = SubmitField('Take Payment')