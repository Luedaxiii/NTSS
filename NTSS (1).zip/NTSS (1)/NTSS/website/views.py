from flask import Blueprint, render_template, request, flash, jsonify, redirect, url_for
from flask_login import login_required, current_user
from .models import Note, Event, Exhibitor, Observer, Speaker, Participant
from . import db
from .forms import EventForm, ParticipantForm
import json

views = Blueprint('views', __name__)


@views.route('/', methods=['GET', 'POST'])
@login_required
def home():
    if request.method == 'POST': 
        note = request.form.get('note')#Gets the note from the HTML 

        if len(note) < 1:
            flash('Note is too short!', category='error') 
        else:
            new_note = Note(data=note, user_id=current_user.id)  #providing the schema for the note 
            db.session.add(new_note) #adding the note to the database 
            db.session.commit()
            flash('Note added!', category='success')

    return render_template("home.html", user=current_user)

@views.route('/create-event', methods=['GET', 'POST'])
@login_required
def create_event():
    if request.method == 'POST':
        event_name = request.form.get('event_name')
        event_description = request.form.get('event_description')

        # Validate event data and create a new event
        if event_name and event_description:
            new_event = Event(name=event_name, description=event_description)
            db.session.add(new_event)
            db.session.commit()
            flash('Event created successfully!', category='success')
            return redirect(url_for('views.manage_events'))
        else:
            flash('Please fill in all required fields.', category='error')

    return render_template("create_event.html", user=current_user)

@views.route('/manage-events', methods=['GET', 'POST'])
def manage_events():
    form = EventForm()
    if form.validate_on_submit():
        # Add new event with sufficient data
        new_event = Event(name=form.name.data, description=form.description.data)
        db.session.add(new_event)
        db.session.commit()
        flash('Event added successfully!', 'success')
        return redirect(url_for('views.manage_events'))
    # Display existing events and form
    events = Event.query.all()
    return render_template('manage_events.html', form=form, events=events, user=current_user)

@views.route('/modify-event/<int:event_id>', methods=['GET', 'POST'])
def modify_event(event_id):
    event = Event.query.get_or_404(event_id)
    form = EventForm(obj=event)
    if form.validate_on_submit():
        event.name = form.name.data
        event.description = form.description.data
        db.session.commit()
        flash('Event modified successfully!', 'success')
        return redirect(url_for('views.manage_events'))
    return render_template('modify_event.html', form=form, event=event, user=current_user)

'''@views.route('/modify-event/<int:event_id>', methods=['GET', 'POST'])
def modify_event(event_id):
    event = Event.query.get_or_404(event_id)
    form = EventForm(obj=event)
    if form.validate_on_submit():
        event.name = form.name.data
        event.description = form.description.data
        db.session.commit()
        flash('Event modified successfully!', 'success')
        return redirect(url_for('views.manage_events'))
    return render_template('modify_event.html', form=form, event=event)'''

@views.route('/delete-event/<int:event_id>')
def delete_event(event_id):
    event = Event.query.get_or_404(event_id)
    db.session.delete(event)
    db.session.commit()
    flash('Event deleted successfully!', 'success')
    return redirect(url_for('views.manage_events'))

@views.route('/delete-note', methods=['POST'])
def delete_note():  
    note = json.loads(request.data) # this function expects a JSON from the INDEX.js file 
    noteId = note['noteId']
    note = Note.query.get(noteId)
    if note:
        if note.user_id == current_user.id:
            db.session.delete(note)
            db.session.commit()

    return jsonify({})


@views.route('/event/<int:event_id>', methods=['GET'])
@login_required
def event_details(event_id):
    event = Event.query.get(event_id)
    if not event:
        flash('Event not found', category='error')
        return redirect(url_for('views.home'))

    # Fetch exhibitors for the event
    exhibitors = Exhibitor.query.filter_by(event_id=event.id).all()

    # Fetch observers for the event
    observers = Observer.query.filter_by(event_id=event.id).all()

    return render_template("event_details.html", event=event, exhibitors=exhibitors, observers=observers)

@views.route('/generate-revenue-report', methods=['GET', 'POST'])
@views.route('/generate-revenue-report/<int:event_id>', methods=['GET'])
@login_required
def generate_revenue_report(event_id=None):
    if event_id:
        # Handle the case where an event_id is provided (GET request)
        event = Event.query.get(event_id)
        if not event:
            flash('Event not found', category='error')
            return redirect(url_for('views.home'))

        # Fetch registrations for the event
        registrations = Registration.query.filter_by(event_id=event.id).all()

        # Calculate total revenue from registrations
        total_revenue = sum(reg.fee for reg in registrations)

        return render_template("revenue_report.html", event=event, registrations=registrations, total_revenue=total_revenue)

    elif request.method == 'POST':
        # Handle the POST request
        event_id = request.form.get('event_id')
        start_date = request.form.get('start_date')
        end_date = request.form.get('end_date')

        # Validate and process the input
        # Fetch the event and generate the report as shown in the previous view

    # Default case, handles general GET request without an event_id
    return render_template("generate_revenue_report.html")

@views.route('/add-participant', methods=['GET', 'POST'])
def add_participant():
    form = ParticipantForm()
    if form.validate_on_submit():
        new_participant = Participant(name=form.name.data, role=form.role.data)
        db.session.add(new_participant)
        db.session.commit()
        flash(f'Participant added with number: {new_participant.participant_number}', 'success')
        return redirect(url_for('views.manage_participants'))
    return render_template('add_participant.html', form=form)

@views.route('/manage-participants')
def manage_participants():
    participants = Participant.query.all()
    return render_template('manage_participants.html', participants=participants)

@views.route('/edit-participant/<int:participant_id>', methods=['GET', 'POST'])
def edit_participant(participant_id):
    participant = Participant.query.get_or_404(participant_id)
    form = ParticipantForm(obj=participant)
    if form.validate_on_submit():
        participant.name = form.name.data
        participant.role = form.role.data
        db.session.commit()
        flash('Participant information updated.', 'success')
        return redirect(url_for('views.manage_participants'))
    return render_template('edit_participant.html', form=form, participant=participant)

@views.route('/delete-participant/<int:participant_id>')
def delete_participant(participant_id):
    participant = Participant.query.get_or_404(participant_id)
    db.session.delete(participant)
    db.session.commit()
    flash('Participant account deleted.', 'success')
    return redirect(url_for('views.manage_participants'))
