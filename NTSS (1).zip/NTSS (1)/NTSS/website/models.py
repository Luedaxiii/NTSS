# models.py

from . import db
from flask_login import UserMixin
from sqlalchemy.sql import func

class Note(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    data = db.Column(db.String(10000))
    date = db.Column(db.DateTime(timezone=True), default=func.now())
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(150), nullable=False)
    first_name = db.Column(db.String(150), nullable=True)  # nullable=True if the first name can be optional
    user_type = db.Column(db.String(50), nullable=False)  # nullable=True if the user type can be optional
    # Relationship with Notes
    notes = db.relationship('Note', backref='user')

    def __init__(self, email, password, first_name=None, user_type=None, **kwargs):
        super(User, self).__init__(**kwargs)
        self.email = email
        self.password = password
        self.first_name = first_name
        self.user_type = user_type

class Event(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.String(1000), nullable=False)
    # ... other necessary fields ...

    # Constructor
    def __init__(self, name, description):
        self.name = name
        self.description = description

'''class Participant(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    participant_number = db.Column(db.String(50), unique=True, nullable=False)
    name = db.Column(db.String(100), nullable=False)
    role = db.Column(db.String(50), nullable=False)  # 'speaker', 'exhibitor', 'observer'

    def __init__(self, name, role):
        self.name = name
        self.role = role
        # Generate a participant number with initial letter based on role
        self.participant_number = self.generate_participant_number(role)'''

class Participant(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(150), unique=True)
    full_name = db.Column(db.String(150))
    # If you have a relationship with booths
    booth = db.relationship('Booth')

    @staticmethod
    def generate_participant_number(role):
        # Here we should generate the participant number based on role
        # For simplicity, we're using a static method and a simple placeholder
        initial = role[0].upper()  # First letter of role, capitalized
        # In a real application, you would also add a unique number or ID here
        return f"{initial}{db.func.random()}"  # Placeholder for example


class Speaker(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    email = db.Column(db.String(150), nullable=False, unique=True)
    # Add other speaker fields as needed

class EventRegistration(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    event_id = db.Column(db.Integer, db.ForeignKey('event.id'), nullable=False)
    speaker_id = db.Column(db.Integer, db.ForeignKey('speaker.id'), nullable=False)
    # Add other event registration fields as needed


class Exhibitor(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    email = db.Column(db.String(150), nullable=False)
    event_id = db.Column(db.Integer, db.ForeignKey('event.id'), nullable=False)
    # Add other fields for exhibitor information as needed

    def __init__(self, name, email, event_id):
        self.name = name
        self.email = email
        self.event_id = event_id
        

class Observer(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    email = db.Column(db.String(150), nullable=False)
    event_id = db.Column(db.Integer, db.ForeignKey('event.id'), nullable=False)
    # Add other fields for observer information as needed

    def __init__(self, name, email, event_id):
        self.name = name
        self.email = email
        self.event_id = event_id

class Registration(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    event_id = db.Column(db.Integer, db.ForeignKey('event.id'))
    participant_id = db.Column(db.Integer)
    fee = db.Column(db.Float)
    date_registered = db.Column(db.DateTime(timezone=True), default=func.now())

    # Define the relationships and back-references
    event = db.relationship('Event', backref='registrations')

class Booth(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    size = db.Column(db.String(100))
    fee = db.Column(db.Float)
    is_available = db.Column(db.Boolean, default=True)
    # Relationship to a Participant model if required
    participant_id = db.Column(db.Integer, db.ForeignKey('participant.id'))