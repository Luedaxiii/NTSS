from flask import Blueprint, render_template, request, flash, redirect, url_for
from .models import User, Event, Exhibitor, Observer, Participant, Speaker, EventRegistration
from .views import views
from werkzeug.security import generate_password_hash, check_password_hash
from . import db
from flask_login import login_user, login_required, logout_user, current_user
from itsdangerous import URLSafeTimedSerializer as Serializer
from .forms import RequestResetForm


auth = Blueprint('auth', __name__)

@auth.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email').strip()  # Use strip to remove any whitespace
        password = request.form.get('password').strip()  # Use strip to remove any whitespace

        user = User.query.filter_by(email=email).first()
        if user:
            # Check the hashed password
            if check_password_hash(user.password, password):
                login_user(user, remember=True)
                flash('Logged in successfully!', category='success')
                return redirect(url_for('views.home'))
            else:
                flash('Wrong password. Please try again.', category='error')
        else:
            flash('Invalid email. Please check your email and try again.', category='error')

    return render_template("login.html", user=current_user)

@auth.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('auth.login'))

@auth.route('/sign-up', methods=['GET', 'POST'])
def sign_up():
    if request.method == 'POST':
        email = request.form.get('email')
        first_name = request.form.get('firstName')
        password1 = request.form.get('password1')
        password2 = request.form.get('password2')
        user_type = request.form.get('user-type')  # Get the selected user type

        user = User.query.filter_by(email=email).first()
        if user:
            flash('Email already exists.', category='error')
        elif len(email) < 4:
            flash('Email must be greater than 3 characters.', category='error')
        elif len(first_name) < 2:
            flash('First name must be greater than 1 character.', category='error')
        elif password1 != password2:
            flash("Passwords don't match.", category='error')
        elif len(password1) < 7:
            flash('Password must be at least 7 characters.', category='error')
        else:
            # Correctly hash the entered password
            hashed_password = generate_password_hash(password1, method='pbkdf2:sha256', salt_length=8)
            new_user = User(email=email, first_name=first_name, password=hashed_password, user_type=user_type)
            db.session.add(new_user)
            db.session.commit()
            login_user(new_user, remember=True)
            flash('Account created!', category='success')
            return redirect(url_for('views.home'))

    return render_template("sign_up.html", user=current_user)

# ... rest of your existing auth routes ...

# Placeholder for additional routes and functionality'''

@auth.route('/create-event', methods=['GET', 'POST'])
def create_event():
    if request.method == 'POST':
        theme = request.form.get('theme and slogan')
        location = request.form.get('location and duration')
        speakers = request.form.get('speakers')
        participants = request.form.get('participants')
        boothsize = request.form.get('booth size')



